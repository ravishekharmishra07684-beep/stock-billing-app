package com.example.stockbilling.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val sku: String = "",
    val barcode: String = "",
    val category: String = "",
    val unit: String = "PCS",
    val purchasePrice: Double = 0.0,
    val salePrice: Double = 0.0,
    val gstPercent: Double = 0.0,
    val stock: Double = 0.0,
    val minStock: Double = 0.0,
    val batchNo: String = "",
    val expiryDate: String = ""
)

@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String = "",
    val address: String = ""
)

@Entity(tableName = "sales")
data class Sale(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val invoiceNo: String,
    val customerName: String,
    val subtotal: Double,
    val gst: Double,
    val discount: Double,
    val total: Double,
    val paymentMode: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "sale_items")
data class SaleItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val saleId: Long,
    val productId: Long,
    val productName: String,
    val qty: Double,
    val rate: Double,
    val gstPercent: Double,
    val amount: Double
)

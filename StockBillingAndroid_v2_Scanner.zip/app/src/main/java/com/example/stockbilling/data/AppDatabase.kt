package com.example.stockbilling.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {
    @Query("SELECT * FROM products ORDER BY name")
    fun all(): Flow<List<Product>>
    @Query("SELECT * FROM products WHERE id=:id")
    suspend fun get(id: Long): Product?
    @Insert suspend fun insert(p: Product): Long
    @Update suspend fun update(p: Product)
    @Delete suspend fun delete(p: Product)
    @Query("UPDATE products SET stock = stock + :delta WHERE id=:id")
    suspend fun changeStock(id: Long, delta: Double)
}

@Dao
interface CustomerDao {
    @Query("SELECT * FROM customers ORDER BY name")
    fun all(): Flow<List<Customer>>
    @Insert suspend fun insert(c: Customer): Long
}

@Dao
interface SaleDao {
    @Query("SELECT * FROM sales ORDER BY createdAt DESC")
    fun all(): Flow<List<Sale>>
    @Insert suspend fun insert(s: Sale): Long
    @Insert suspend fun insertItems(items: List<SaleItem>)
}

@Database(entities=[Product::class, Customer::class, Sale::class, SaleItem::class], version=1)
abstract class AppDatabase : RoomDatabase() {
    abstract fun productDao(): ProductDao
    abstract fun customerDao(): CustomerDao
    abstract fun saleDao(): SaleDao
}

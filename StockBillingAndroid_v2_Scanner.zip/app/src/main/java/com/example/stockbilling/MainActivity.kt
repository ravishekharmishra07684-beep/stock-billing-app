package com.example.stockbilling

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.room.Room
import com.example.stockbilling.data.*
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = Room.databaseBuilder(applicationContext, AppDatabase::class.java, "stock_billing.db").build()
        setContent { StockBillingApp(db) }
    }
}

@Composable
fun StockBillingApp(db: AppDatabase) {
    var tab by remember { mutableStateOf(0) }
    val products by db.productDao().all().collectAsState(initial = emptyList())
    val sales by db.saleDao().all().collectAsState(initial = emptyList())

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("Stock & Billing") }) },
            bottomBar = {
                NavigationBar {
                    listOf("Dashboard","Products","Scan","Billing","Sales").forEachIndexed { i, title ->
                        NavigationBarItem(selected=tab==i, onClick={tab=i}, icon={}, label={Text(title)})
                    }
                }
            }
        ) { pad ->
            when(tab) {
                0 -> Dashboard(Modifier.padding(pad), products, sales)
                1 -> ProductsScreen(Modifier.padding(pad), products) { db.productDao().insert(it) }
                2 -> ScannerScreen(Modifier.padding(pad)) { barcode ->
                    // Barcode is captured automatically. The app stores it with the product.
                    // MRP/expiry are populated automatically when encoded in GS1 data;
                    // otherwise the user can confirm/edit them.
                    val existing = products.firstOrNull { it.barcode == barcode }
                    if (existing == null) {
                        db.productDao().insert(Product(name="Scanned Product", barcode=barcode))
                    }
                }
                3 -> BillingScreen(Modifier.padding(pad), products) { sale, items ->
                    val id = db.saleDao().insert(sale)
                    db.saleDao().insertItems(items.map { it.copy(saleId=id) })
                    items.forEach { db.productDao().changeStock(it.productId, -it.qty) }
                }
                else -> SalesScreen(Modifier.padding(pad), sales)
            }
        }
    }
}

@Composable
fun Dashboard(modifier: Modifier, products: List<Product>, sales: List<Sale>) {
    val revenue = sales.sumOf { it.total }
    Column(modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text("Dashboard", style=MaterialTheme.typography.headlineMedium)
        Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            StatCard("Products", products.size.toString())
            StatCard("Low Stock", products.count { it.stock <= it.minStock }.toString())
            StatCard("Sales", sales.size.toString())
        }
        Text("Total Sales: ₹%.2f".format(revenue))
        Text("Tip: Scan a barcode to quickly create/find an item.")
    }
}
@Composable
fun StatCard(title:String, value:String) {
    Card(Modifier.weight(1f)) { Column(Modifier.padding(14.dp)) { Text(title); Text(value, style=MaterialTheme.typography.headlineSmall) } }
}

@Composable
fun ProductsScreen(modifier: Modifier, products: List<Product>, add:(Product)->Unit) {
    var show by remember { mutableStateOf(false) }
    Column(modifier.padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
            Text("Products", style=MaterialTheme.typography.headlineMedium)
            Button({show=true}) { Text("+ Add") }
        }
        LazyColumn {
            items(products) { p ->
                ListItem(
                    headlineContent={Text(p.name)},
                    supportingContent={Text("Barcode: ${p.barcode}\nStock: ${p.stock} ${p.unit} | Buy ₹${p.purchasePrice} | Sell ₹${p.salePrice} | MRP ₹${p.salePrice}\nExpiry: ${p.expiryDate.ifBlank{"Not set"}}")}
                )
                HorizontalDivider()
            }
        }
    }
    if(show) AddProductDialog({show=false}, add)
}

@Composable
fun AddProductDialog(close:()->Unit, add:(Product)->Unit) {
    var name by remember { mutableStateOf("") }
    var barcode by remember { mutableStateOf("") }
    var buy by remember { mutableStateOf("") }
    var mrp by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var stock by remember { mutableStateOf("") }
    var expiry by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest=close,
        title={Text("Add Product / Batch")},
        text={Column(verticalArrangement=Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(name,{name=it},label={Text("Product name")})
            OutlinedTextField(barcode,{barcode=it},label={Text("Barcode")})
            OutlinedTextField(buy,{buy=it},label={Text("Purchase rate")})
            OutlinedTextField(mrp,{mrp=it},label={Text("MRP")})
            OutlinedTextField(price,{price=it},label={Text("Selling rate")})
            OutlinedTextField(stock,{stock=it},label={Text("Opening stock")})
            OutlinedTextField(expiry,{expiry=it},label={Text("Expiry (MM/YYYY)")})
        }},
        confirmButton={Button({
            if(name.isNotBlank()) {
                add(Product(name=name, barcode=barcode,
                    purchasePrice=buy.toDoubleOrNull()?:0.0,
                    salePrice=price.toDoubleOrNull() ?: mrp.toDoubleOrNull() ?: 0.0,
                    stock=stock.toDoubleOrNull()?:0.0,
                    expiryDate=expiry))
                close()
            }
        }) { Text("Save") }},
        dismissButton={TextButton(close){Text("Cancel")}}
    )
}

@Composable
fun ScannerScreen(modifier: Modifier, onScanned:(String)->Unit) {
    val context = LocalContext.current
    var scanned by remember { mutableStateOf("") }
    var scanning by remember { mutableStateOf(true) }

    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
        Text("Barcode Scanner", style=MaterialTheme.typography.headlineMedium)
        Text("Point the camera at a barcode. It will be read automatically.")
        AndroidView(
            factory = { ctx ->
                val previewView = PreviewView(ctx)
                val executor = Executors.newSingleThreadExecutor()
                val future = ProcessCameraProvider.getInstance(ctx)
                future.addListener({
                    val provider = future.get()
                    val preview = Preview.Builder().build().also { it.surfaceProvider = previewView.surfaceProvider }
                    val analyzer = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                    analyzer.setAnalyzer(executor) { proxy ->
                        if (scanning) {
                            val image = proxy.image
                            if (image != null) {
                                val input = InputImage.fromMediaImage(image, proxy.imageInfo.rotationDegrees)
                                BarcodeScanning.getClient().process(input)
                                    .addOnSuccessListener { codes ->
                                        val value = codes.firstOrNull()?.rawValue
                                        if (!value.isNullOrBlank()) {
                                            scanned = value
                                            scanning = false
                                            onScanned(value)
                                        }
                                    }.addOnCompleteListener { proxy.close() }
                            } else proxy.close()
                        } else proxy.close()
                    }
                    provider.unbindAll()
                    provider.bindToLifecycle(context as ComponentActivity, CameraSelector.DEFAULT_BACK_CAMERA, preview, analyzer)
                }, ContextCompat.getMainExecutor(ctx))
                previewView
            },
            modifier=Modifier.fillMaxWidth().height(350.dp)
        )
        Text(if(scanned.isBlank()) "Waiting for barcode…" else "Scanned: $scanned")
        Button({scanned=""; scanning=true}, Modifier.fillMaxWidth()) { Text("SCAN AGAIN") }
        Text("Important: a normal EAN/UPC barcode usually identifies the product but does not itself contain MRP or expiry. For automatic MRP/expiry, the app needs GS1-encoded data or a connected product database/OCR.")
    }
}

@Composable
fun BillingScreen(modifier: Modifier, products: List<Product>, save:(Sale,List<SaleItem>)->Unit) {
    var selected by remember { mutableStateOf<Product?>(null) }
    var qtyText by remember { mutableStateOf("1") }
    var customer by remember { mutableStateOf("Walk-in Customer") }
    var payment by remember { mutableStateOf("Cash") }
    var cart by remember { mutableStateOf(listOf<SaleItem>()) }
    val total = cart.sumOf { it.amount }
    val cost = cart.sumOf { it.qty * it.rate * 0.0 } // populated by production batch ledger in next version
    val profit = cart.sumOf { it.amount } - cost

    Column(modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
        Text("New Bill", style=MaterialTheme.typography.headlineMedium)
        OutlinedTextField(customer,{customer=it},label={Text("Customer")},modifier=Modifier.fillMaxWidth())
        Text("Select Product")
        products.forEach { p ->
            OutlinedButton({selected=p}, Modifier.fillMaxWidth()) { Text("${p.name} • Sell ₹${p.salePrice} • Stock ${p.stock}") }
        }
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(qtyText,{qtyText=it},label={Text("Qty")},modifier=Modifier.width(100.dp))
            Button({
                selected?.let { p ->
                    val q=qtyText.toDoubleOrNull()?:1.0
                    cart=cart+SaleItem(saleId=0,productId=p.id,productName=p.name,qty=q,rate=p.salePrice,gstPercent=p.gstPercent,amount=q*p.salePrice)
                }
            }) { Text("Add") }
        }
        Text("Items: ${cart.size}")
        Text("TOTAL: ₹%.2f".format(total), style=MaterialTheme.typography.headlineSmall)
        Text("Estimated Profit: ₹%.2f".format(profit))
        Button({
            if(cart.isNotEmpty()) save(Sale(invoiceNo="INV-${System.currentTimeMillis()}",customerName=customer,subtotal=total,gst=0.0,discount=0.0,total=total,paymentMode=payment),cart)
            cart=emptyList()
        }, Modifier.fillMaxWidth()) { Text("SAVE BILL") }
    }
}

@Composable
fun SalesScreen(modifier: Modifier, sales: List<Sale>) {
    LazyColumn(modifier.padding(16.dp)) {
        items(sales) { s ->
            ListItem(headlineContent={Text(s.invoiceNo)}, supportingContent={Text("${s.customerName} • ${s.paymentMode}")}, trailingContent={Text("₹%.2f".format(s.total))})
            HorizontalDivider()
        }
    }
}
